Sys.unsetenv("R_TESTS")
library(testthat)
test_check("celda")
